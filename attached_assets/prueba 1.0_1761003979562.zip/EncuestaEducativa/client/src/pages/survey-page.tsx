import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { Redirect, useLocation } from "wouter";
import { SurveyQuestion, InsertSurveyResponse } from "@shared/schema";
import { ClipboardCheck, ChevronLeft, ChevronRight, Save } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { ThemeToggle } from "@/components/theme-toggle";

type SurveyFormData = {
  [questionId: string]: {
    responseText?: string;
    responseValue?: number;
  };
};

export default function SurveyPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState<SurveyFormData>({});

  const { data: questions, isLoading: questionsLoading } = useQuery<SurveyQuestion[]>({
    queryKey: ["/api/survey/questions"],
    enabled: user?.role === "student",
  });

  const { data: studentData } = useQuery({
    queryKey: ["/api/student/profile"],
    enabled: user?.role === "student",
  });

  const submitSurveyMutation = useMutation({
    mutationFn: async (responses: InsertSurveyResponse[]) => {
      const res = await apiRequest("POST", "/api/survey/responses", { responses });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/student/profile"] });
      toast({
        title: "¡Encuesta completada!",
        description: "Tu perfil cognitivo ha sido generado exitosamente.",
      });
      navigate("/");
    },
    onError: (error: Error) => {
      toast({
        title: "Error al enviar encuesta",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Redirect if not a student or already completed survey
  if (user?.role !== "student") {
    return <Redirect to="/" />;
  }

  if (studentData && studentData.surveyCompleted) {
    return <Redirect to="/" />;
  }

  if (questionsLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Skeleton className="h-96 w-full max-w-2xl" />
      </div>
    );
  }

  if (!questions || questions.length === 0) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>No hay encuestas disponibles</CardTitle>
            <CardDescription>
              Por favor, contacta a tu profesor para obtener más información.
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  const currentQuestion = questions[currentStep];
  const totalQuestions = questions.length;
  const progress = ((currentStep + 1) / totalQuestions) * 100;

  const handleNext = () => {
    if (currentStep < totalQuestions - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = () => {
    if (!studentData?.id) return;

    const responses: InsertSurveyResponse[] = Object.entries(formData).map(
      ([questionId, data]) => ({
        studentId: studentData.id,
        questionId,
        responseText: data.responseText,
        responseValue: data.responseValue,
      })
    );

    submitSurveyMutation.mutate(responses);
  };

  const updateResponse = (questionId: string, data: { responseText?: string; responseValue?: number }) => {
    setFormData(prev => ({
      ...prev,
      [questionId]: {
        ...prev[questionId],
        ...data,
      }
    }));
  };

  const isCurrentQuestionAnswered = () => {
    const response = formData[currentQuestion.id];
    if (!response) return false;
    
    if (currentQuestion.questionType === "text") {
      return !!response.responseText && response.responseText.trim().length > 0;
    }
    
    return response.responseValue !== undefined;
  };

  const renderQuestionInput = () => {
    const currentResponse = formData[currentQuestion.id];

    switch (currentQuestion.questionType) {
      case "cognitive_scale":
        return (
          <div className="space-y-4">
            <div className="flex justify-between text-sm text-muted-foreground mb-2">
              <span>Totalmente en desacuerdo</span>
              <span>Neutral</span>
              <span>Totalmente de acuerdo</span>
            </div>
            <Slider
              value={[currentResponse?.responseValue ?? 0]}
              onValueChange={(value) => updateResponse(currentQuestion.id, { responseValue: value[0] })}
              min={-100}
              max={100}
              step={10}
              className="py-4"
              data-testid="slider-cognitive"
            />
            <div className="text-center text-sm font-medium">
              Valor: {currentResponse?.responseValue ?? 0}
            </div>
          </div>
        );

      case "likert":
        return (
          <RadioGroup
            value={currentResponse?.responseValue?.toString() || ""}
            onValueChange={(value) => updateResponse(currentQuestion.id, { responseValue: parseInt(value) })}
            className="space-y-3"
          >
            {[1, 2, 3, 4, 5].map((value) => (
              <div key={value} className="flex items-center space-x-2" data-testid={`radio-likert-${value}`}>
                <RadioGroupItem value={value.toString()} id={`option-${value}`} />
                <Label htmlFor={`option-${value}`} className="cursor-pointer flex-1">
                  {value === 1 && "Totalmente en desacuerdo"}
                  {value === 2 && "En desacuerdo"}
                  {value === 3 && "Neutral"}
                  {value === 4 && "De acuerdo"}
                  {value === 5 && "Totalmente de acuerdo"}
                </Label>
              </div>
            ))}
          </RadioGroup>
        );

      case "multiple_choice":
        return (
          <RadioGroup
            value={currentResponse?.responseText || ""}
            onValueChange={(value) => updateResponse(currentQuestion.id, { responseText: value })}
            className="space-y-3"
          >
            {currentQuestion.options?.map((option, idx) => (
              <div key={idx} className="flex items-center space-x-2">
                <RadioGroupItem value={option} id={`choice-${idx}`} />
                <Label htmlFor={`choice-${idx}`} className="cursor-pointer flex-1">
                  {option}
                </Label>
              </div>
            ))}
          </RadioGroup>
        );

      case "text":
        return (
          <Textarea
            value={currentResponse?.responseText || ""}
            onChange={(e) => updateResponse(currentQuestion.id, { responseText: e.target.value })}
            placeholder="Escribe tu respuesta aquí..."
            className="min-h-32"
            data-testid="textarea-response"
          />
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <ClipboardCheck className="h-6 w-6 text-primary" />
            <h1 className="text-xl font-bold text-foreground">Encuesta Personal</h1>
          </div>
          <ThemeToggle />
        </div>
      </header>

      <main className="container max-w-2xl mx-auto px-4 py-8">
        {/* Progress */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <h2 className="text-sm font-medium text-muted-foreground">
              Pregunta {currentStep + 1} de {totalQuestions}
            </h2>
            <span className="text-sm font-medium text-primary">
              {progress.toFixed(0)}% completado
            </span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Question Card */}
        <Card className="mb-8">
          <CardHeader>
            <div className="flex items-start gap-2">
              <div className="bg-primary/10 text-primary font-bold rounded-full h-8 w-8 flex items-center justify-center flex-shrink-0 text-sm">
                {currentStep + 1}
              </div>
              <div className="flex-1">
                <CardTitle className="text-xl mb-2">
                  {currentQuestion.questionText}
                </CardTitle>
                <CardDescription>
                  Categoría: {currentQuestion.category.replace(/_/g, " ")}
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            {renderQuestionInput()}
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between items-center gap-4">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentStep === 0}
            data-testid="button-previous"
          >
            <ChevronLeft className="h-4 w-4 mr-2" />
            Anterior
          </Button>

          <div className="flex gap-2">
            {currentStep === totalQuestions - 1 ? (
              <Button
                onClick={handleSubmit}
                disabled={!isCurrentQuestionAnswered() || submitSurveyMutation.isPending}
                data-testid="button-submit-survey"
              >
                <Save className="h-4 w-4 mr-2" />
                {submitSurveyMutation.isPending ? "Enviando..." : "Finalizar Encuesta"}
              </Button>
            ) : (
              <Button
                onClick={handleNext}
                disabled={!isCurrentQuestionAnswered()}
                data-testid="button-next"
              >
                Siguiente
                <ChevronRight className="h-4 w-4 ml-2" />
              </Button>
            )}
          </div>
        </div>

        {/* Helper Text */}
        <p className="text-center text-sm text-muted-foreground mt-6">
          Tus respuestas nos ayudarán a generar tu perfil cognitivo personalizado
        </p>
      </main>
    </div>
  );
}
