import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Users, 
  TrendingUp, 
  CheckCircle2, 
  Search,
  BarChart3,
  AlertCircle
} from "lucide-react";
import { useState } from "react";
import { StudentWithUser } from "@shared/schema";
import { ThemeToggle } from "@/components/theme-toggle";

type DashboardStats = {
  totalStudents: number;
  averageGrade: number;
  completionRate: number;
  surveysCompleted: number;
};

export default function TeacherDashboard() {
  const { user, logoutMutation } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");

  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/teacher/stats"],
    enabled: user?.role === "teacher",
  });

  const { data: students, isLoading: studentsLoading } = useQuery<StudentWithUser[]>({
    queryKey: ["/api/teacher/students"],
    enabled: user?.role === "teacher",
  });

  const isLoading = statsLoading || studentsLoading;

  const filteredStudents = students?.filter(student => {
    const searchLower = searchTerm.toLowerCase();
    return (
      student.user.firstName.toLowerCase().includes(searchLower) ||
      student.user.lastName.toLowerCase().includes(searchLower) ||
      student.studentId.toLowerCase().includes(searchLower) ||
      student.career.toLowerCase().includes(searchLower)
    );
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-2xl font-bold text-foreground">ITSU Analytics</h1>
            <Badge className="text-xs">Profesor</Badge>
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button 
              variant="ghost" 
              onClick={() => logoutMutation.mutate()}
              data-testid="button-logout"
            >
              Cerrar Sesión
            </Button>
          </div>
        </div>
      </header>

      <main className="container max-w-7xl mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-foreground mb-2">
            Panel de Profesor
          </h2>
          <p className="text-muted-foreground">
            Bienvenido, {user?.firstName}. Aquí puedes monitorear el progreso de tus estudiantes.
          </p>
        </div>

        {isLoading ? (
          <div className="grid gap-6 md:grid-cols-4 mb-8">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-4 w-24" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-8 w-16" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <>
            {/* Global Metrics */}
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Estudiantes Activos
                  </CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {stats?.totalStudents || 0}
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Total registrados
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Promedio General
                  </CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {stats?.averageGrade ? stats.averageGrade.toFixed(2) : "N/A"}
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Calificación del grupo
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Tasa de Finalización
                  </CardTitle>
                  <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {stats?.completionRate ? stats.completionRate.toFixed(1) : "0"}%
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Actividades completadas
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Encuestas Completadas
                  </CardTitle>
                  <BarChart3 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {stats?.surveysCompleted || 0}/{stats?.totalStudents || 0}
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Perfiles cognitivos generados
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Students List */}
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div>
                    <CardTitle>Lista de Estudiantes</CardTitle>
                    <CardDescription>
                      Gestiona y monitorea el progreso de tus estudiantes
                    </CardDescription>
                  </div>
                  <div className="relative w-full sm:w-64">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Buscar estudiante..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-8"
                      data-testid="input-search"
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {!students || students.length === 0 ? (
                  <div className="text-center py-12">
                    <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No hay estudiantes registrados</h3>
                    <p className="text-sm text-muted-foreground">
                      Los estudiantes aparecerán aquí una vez que se registren en el sistema.
                    </p>
                  </div>
                ) : (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Matrícula</TableHead>
                          <TableHead>Nombre</TableHead>
                          <TableHead>Carrera</TableHead>
                          <TableHead>Semestre</TableHead>
                          <TableHead>Promedio</TableHead>
                          <TableHead>Encuesta</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredStudents && filteredStudents.length > 0 ? (
                          filteredStudents.map((student) => (
                            <TableRow key={student.id} data-testid={`row-student-${student.id}`}>
                              <TableCell className="font-mono text-sm">
                                {student.studentId}
                              </TableCell>
                              <TableCell>
                                {student.user.firstName} {student.user.lastName}
                              </TableCell>
                              <TableCell>{student.career}</TableCell>
                              <TableCell>{student.semester}°</TableCell>
                              <TableCell>
                                {student.average ? Number(student.average).toFixed(2) : "N/A"}
                              </TableCell>
                              <TableCell>
                                {student.surveyCompleted ? (
                                  <Badge variant="default" className="bg-green-600">
                                    <CheckCircle2 className="h-3 w-3 mr-1" />
                                    Completada
                                  </Badge>
                                ) : (
                                  <Badge variant="secondary">
                                    <AlertCircle className="h-3 w-3 mr-1" />
                                    Pendiente
                                  </Badge>
                                )}
                              </TableCell>
                            </TableRow>
                          ))
                        ) : (
                          <TableRow>
                            <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                              No se encontraron estudiantes que coincidan con tu búsqueda
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </>
        )}
      </main>
    </div>
  );
}
