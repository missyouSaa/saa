import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { 
  ClipboardList, 
  TrendingUp, 
  Calendar, 
  AlertCircle,
  CheckCircle2,
  Target
} from "lucide-react";
import { Link } from "wouter";
import { Student, WeeklyProgress } from "@shared/schema";
import { ThemeToggle } from "@/components/theme-toggle";

export default function StudentDashboard() {
  const { user, logoutMutation } = useAuth();

  const { data: studentData, isLoading: studentLoading } = useQuery<Student>({
    queryKey: ["/api/student/profile"],
    enabled: user?.role === "student",
  });

  const { data: weeklyProgress, isLoading: progressLoading } = useQuery<WeeklyProgress[]>({
    queryKey: ["/api/student/progress"],
    enabled: user?.role === "student",
  });

  const isLoading = studentLoading || progressLoading;

  const getCurrentWeek = () => {
    return weeklyProgress?.find(w => w.week === Math.min(...weeklyProgress.map(p => p.week))) || null;
  };

  const calculateOverallProgress = () => {
    if (!weeklyProgress || weeklyProgress.length === 0) return 0;
    const total = weeklyProgress.reduce((acc, w) => acc + w.tasksCompleted, 0);
    const max = weeklyProgress.reduce((acc, w) => acc + w.tasksTotal, 0);
    return max > 0 ? (total / max) * 100 : 0;
  };

  const getCognitiveProfileLabel = (value: number, negative: string, positive: string) => {
    if (value < -30) return negative;
    if (value > 30) return positive;
    return "Balanceado";
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-2xl font-bold text-foreground">ITSU Analytics</h1>
            <Badge variant="secondary" className="text-xs">Estudiante</Badge>
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button 
              variant="ghost" 
              onClick={() => logoutMutation.mutate()}
              data-testid="button-logout"
            >
              Cerrar Sesión
            </Button>
          </div>
        </div>
      </header>

      <main className="container max-w-7xl mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-foreground mb-2">
            ¡Hola, {user?.firstName}!
          </h2>
          <p className="text-muted-foreground">
            Bienvenido a tu panel personal de seguimiento académico
          </p>
        </div>

        {isLoading ? (
          <div className="grid gap-6 md:grid-cols-3 mb-8">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-4 w-24" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-8 w-16 mb-2" />
                  <Skeleton className="h-3 w-32" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <>
            {/* Survey Alert */}
            {studentData && !studentData.surveyCompleted && (
              <Alert className="mb-8 border-primary/50 bg-primary/5">
                <AlertCircle className="h-5 w-5 text-primary" />
                <AlertTitle>Encuesta Pendiente</AlertTitle>
                <AlertDescription className="mt-2">
                  <p className="mb-4">
                    Completa tu encuesta personal para que podamos generar tu perfil cognitivo 
                    y brindarte recomendaciones personalizadas.
                  </p>
                  <Link href="/survey">
                    <Button size="sm" data-testid="button-take-survey">
                      <ClipboardList className="h-4 w-4 mr-2" />
                      Completar Encuesta
                    </Button>
                  </Link>
                </AlertDescription>
              </Alert>
            )}

            {/* Metrics Overview */}
            <div className="grid gap-6 md:grid-cols-3 mb-8">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Progreso General
                  </CardTitle>
                  <Target className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {calculateOverallProgress().toFixed(1)}%
                  </div>
                  <Progress value={calculateOverallProgress()} className="mt-2" />
                  <p className="text-xs text-muted-foreground mt-2">
                    Tareas completadas
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Promedio Actual
                  </CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {studentData?.average ? Number(studentData.average).toFixed(2) : "N/A"}
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Calificación promedio
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Tasa de Finalización
                  </CardTitle>
                  <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {studentData?.completionRate ? Number(studentData.completionRate).toFixed(1) : "0"}%
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Actividades completadas
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Student Information */}
            {studentData && (
              <div className="grid gap-6 md:grid-cols-2 mb-8">
                <Card>
                  <CardHeader>
                    <CardTitle>Información Académica</CardTitle>
                    <CardDescription>Datos de tu perfil estudiantil</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Matrícula</p>
                      <p className="text-base font-mono">{studentData.studentId}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Carrera</p>
                      <p className="text-base">{studentData.career}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Semestre</p>
                      <p className="text-base">{studentData.semester}°</p>
                    </div>
                    {studentData.cluster && (
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Cluster</p>
                        <Badge variant="outline">{studentData.cluster}</Badge>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {studentData.surveyCompleted && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Perfil Cognitivo</CardTitle>
                      <CardDescription>Tus preferencias de aprendizaje</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-2">
                          <span className="text-sm text-muted-foreground">Secuencial</span>
                          <span className="text-sm font-medium">
                            {getCognitiveProfileLabel(
                              studentData.profileSequentialGlobal || 0,
                              "Secuencial",
                              "Global"
                            )}
                          </span>
                          <span className="text-sm text-muted-foreground">Global</span>
                        </div>
                        <Progress 
                          value={((studentData.profileSequentialGlobal || 0) + 100) / 2} 
                          className="h-2"
                        />
                      </div>

                      <div>
                        <div className="flex justify-between mb-2">
                          <span className="text-sm text-muted-foreground">Activo</span>
                          <span className="text-sm font-medium">
                            {getCognitiveProfileLabel(
                              studentData.profileActiveReflective || 0,
                              "Activo",
                              "Reflexivo"
                            )}
                          </span>
                          <span className="text-sm text-muted-foreground">Reflexivo</span>
                        </div>
                        <Progress 
                          value={((studentData.profileActiveReflective || 0) + 100) / 2} 
                          className="h-2"
                        />
                      </div>

                      <div>
                        <div className="flex justify-between mb-2">
                          <span className="text-sm text-muted-foreground">Sensorial</span>
                          <span className="text-sm font-medium">
                            {getCognitiveProfileLabel(
                              studentData.profileSensorialIntuitive || 0,
                              "Sensorial",
                              "Intuitivo"
                            )}
                          </span>
                          <span className="text-sm text-muted-foreground">Intuitivo</span>
                        </div>
                        <Progress 
                          value={((studentData.profileSensorialIntuitive || 0) + 100) / 2} 
                          className="h-2"
                        />
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}

            {/* Weekly Progress */}
            {weeklyProgress && weeklyProgress.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    Progreso Semanal
                  </CardTitle>
                  <CardDescription>
                    Tu rendimiento a lo largo del semestre
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-4">
                    {weeklyProgress.slice(0, 16).map((week) => (
                      <div
                        key={week.id}
                        className="border rounded-md p-3 text-center hover-elevate"
                      >
                        <p className="text-xs font-medium text-muted-foreground mb-1">
                          Sem {week.week}
                        </p>
                        <p className="text-lg font-bold">
                          {week.tasksCompleted}/{week.tasksTotal}
                        </p>
                        {week.averageScore && (
                          <p className="text-xs text-muted-foreground mt-1">
                            {Number(week.averageScore).toFixed(1)}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </>
        )}
      </main>
    </div>
  );
}
