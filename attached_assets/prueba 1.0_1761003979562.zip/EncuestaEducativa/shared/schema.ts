import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, decimal, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table with role (student or teacher)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  role: text("role").notNull(), // 'student' or 'teacher'
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Students table - extended profile for students
export const students = pgTable("students", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  studentId: text("student_id").notNull().unique(), // Matricula
  career: text("career").notNull(), // Carrera
  semester: integer("semester").notNull(),
  average: decimal("average", { precision: 4, scale: 2 }).default("0"),
  completionRate: decimal("completion_rate", { precision: 5, scale: 2 }).default("0"),
  cluster: text("cluster"),
  // Cognitive profile dimensions (scales from -100 to 100)
  profileSequentialGlobal: integer("profile_sequential_global").default(0), // -100=Sequential, 100=Global
  profileActiveReflective: integer("profile_active_reflective").default(0), // -100=Active, 100=Reflective
  profileSensorialIntuitive: integer("profile_sensorial_intuitive").default(0), // -100=Sensorial, 100=Intuitive
  surveyCompleted: boolean("survey_completed").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Survey questions
export const surveyQuestions = pgTable("survey_questions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  questionText: text("question_text").notNull(),
  questionType: text("question_type").notNull(), // 'likert', 'text', 'multiple_choice', 'cognitive_scale'
  category: text("category").notNull(), // 'personal_info', 'cognitive_profile', 'learning_preferences'
  options: text("options").array(), // For multiple choice questions
  cognitiveProfileDimension: text("cognitive_profile_dimension"), // 'sequential_global', 'active_reflective', 'sensorial_intuitive'
  order: integer("order").notNull(),
});

// Survey responses from students
export const surveyResponses = pgTable("survey_responses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentId: varchar("student_id").notNull().references(() => students.id, { onDelete: "cascade" }),
  questionId: varchar("question_id").notNull().references(() => surveyQuestions.id, { onDelete: "cascade" }),
  responseText: text("response_text"),
  responseValue: integer("response_value"), // For likert scales and cognitive profiles
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Weekly progress tracking
export const weeklyProgress = pgTable("weekly_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentId: varchar("student_id").notNull().references(() => students.id, { onDelete: "cascade" }),
  week: integer("week").notNull(), // 1-16
  tasksCompleted: integer("tasks_completed").default(0),
  tasksTotal: integer("tasks_total").default(0),
  averageScore: decimal("average_score", { precision: 5, scale: 2 }).default("0"),
  isPreDSS: boolean("is_pre_dss").default(false),
});

// Zod schemas for validation
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
}).extend({
  password: z.string().min(6, "Password must be at least 6 characters"),
  email: z.string().email("Invalid email address"),
  role: z.enum(["student", "teacher"]),
});

export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
  createdAt: true,
  surveyCompleted: true,
});

export const insertSurveyQuestionSchema = createInsertSchema(surveyQuestions).omit({
  id: true,
});

export const insertSurveyResponseSchema = createInsertSchema(surveyResponses).omit({
  id: true,
  createdAt: true,
});

export const insertWeeklyProgressSchema = createInsertSchema(weeklyProgress).omit({
  id: true,
});

// TypeScript types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginData = z.infer<typeof loginSchema>;

export type Student = typeof students.$inferSelect;
export type InsertStudent = z.infer<typeof insertStudentSchema>;

export type SurveyQuestion = typeof surveyQuestions.$inferSelect;
export type InsertSurveyQuestion = z.infer<typeof insertSurveyQuestionSchema>;

export type SurveyResponse = typeof surveyResponses.$inferSelect;
export type InsertSurveyResponse = z.infer<typeof insertSurveyResponseSchema>;

export type WeeklyProgress = typeof weeklyProgress.$inferSelect;
export type InsertWeeklyProgress = z.infer<typeof insertWeeklyProgressSchema>;

// Extended types for frontend
export type StudentWithUser = Student & {
  user: User;
};

export type UserWithStudent = User & {
  student?: Student;
};
