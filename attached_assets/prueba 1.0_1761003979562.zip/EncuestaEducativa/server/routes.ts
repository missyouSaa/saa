// Referenced from javascript_auth_all_persistance blueprint
import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import {
  insertStudentSchema,
  insertSurveyResponseSchema,
  insertWeeklyProgressSchema,
} from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";

// Middleware to check if user is authenticated
function requireAuth(req: Request, res: Response, next: Function) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ error: "Authentication required" });
  }
  next();
}

// Middleware to check if user is a student
function requireStudent(req: Request, res: Response, next: Function) {
  if (!req.user || req.user.role !== "student") {
    return res.status(403).json({ error: "Student access required" });
  }
  next();
}

// Middleware to check if user is a teacher
function requireTeacher(req: Request, res: Response, next: Function) {
  if (!req.user || req.user.role !== "teacher") {
    return res.status(403).json({ error: "Teacher access required" });
  }
  next();
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes: /api/register, /api/login, /api/logout, /api/user
  setupAuth(app);

  // Seed survey questions on startup
  await storage.seedSurveyQuestions();

  // Student Routes

  // Get student profile (for current logged-in student)
  app.get("/api/student/profile", requireAuth, requireStudent, async (req, res) => {
    try {
      const student = await storage.getStudentByUserId(req.user!.id);

      if (!student) {
        // If student doesn't exist, create a default profile
        const newStudent = await storage.createStudent({
          userId: req.user!.id,
          studentId: `TEMP-${req.user!.id.substring(0, 8)}`,
          career: "Por definir",
          semester: 1,
        });
        return res.json(newStudent);
      }

      res.json(student);
    } catch (error) {
      console.error("Error fetching student profile:", error);
      res.status(500).json({ error: "Failed to fetch student profile" });
    }
  });

  // Create or update student profile
  app.post("/api/student/profile", requireAuth, requireStudent, async (req, res) => {
    try {
      const existingStudent = await storage.getStudentByUserId(req.user!.id);

      if (existingStudent) {
        const updated = await storage.updateStudent(existingStudent.id, req.body);
        return res.json(updated);
      }

      const validated = insertStudentSchema.parse({
        ...req.body,
        userId: req.user!.id,
      });

      const student = await storage.createStudent(validated);
      res.status(201).json(student);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      console.error("Error creating student profile:", error);
      res.status(500).json({ error: "Failed to create student profile" });
    }
  });

  // Get weekly progress for current student
  app.get("/api/student/progress", requireAuth, requireStudent, async (req, res) => {
    try {
      const student = await storage.getStudentByUserId(req.user!.id);
      if (!student) {
        return res.json([]);
      }

      const progress = await storage.getStudentWeeklyProgress(student.id);
      res.json(progress);
    } catch (error) {
      console.error("Error fetching weekly progress:", error);
      res.status(500).json({ error: "Failed to fetch weekly progress" });
    }
  });

  // Survey Routes

  // Get all survey questions
  app.get("/api/survey/questions", requireAuth, async (req, res) => {
    try {
      const questions = await storage.getAllSurveyQuestions();
      res.json(questions);
    } catch (error) {
      console.error("Error fetching survey questions:", error);
      res.status(500).json({ error: "Failed to fetch survey questions" });
    }
  });

  // Submit survey responses
  app.post("/api/survey/responses", requireAuth, requireStudent, async (req, res) => {
    try {
      const student = await storage.getStudentByUserId(req.user!.id);
      if (!student) {
        return res.status(404).json({ error: "Student profile not found" });
      }

      const { responses } = req.body;

      if (!Array.isArray(responses)) {
        return res.status(400).json({ error: "Responses must be an array" });
      }

      // Validate all responses
      const validatedResponses = responses.map((response) =>
        insertSurveyResponseSchema.parse({
          ...response,
          studentId: student.id,
        })
      );

      await storage.createMultipleSurveyResponses(validatedResponses);

      res.status(201).json({ success: true, message: "Survey responses saved successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      console.error("Error saving survey responses:", error);
      res.status(500).json({ error: "Failed to save survey responses" });
    }
  });

  // Teacher Routes

  // Get all students with their user data
  app.get("/api/teacher/students", requireAuth, requireTeacher, async (req, res) => {
    try {
      const students = await storage.getAllStudentsWithUsers();
      res.json(students);
    } catch (error) {
      console.error("Error fetching students:", error);
      res.status(500).json({ error: "Failed to fetch students" });
    }
  });

  // Get teacher dashboard stats
  app.get("/api/teacher/stats", requireAuth, requireTeacher, async (req, res) => {
    try {
      const stats = await storage.getTeacherStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching teacher stats:", error);
      res.status(500).json({ error: "Failed to fetch teacher stats" });
    }
  });

  // Create weekly progress entry (for testing/admin purposes)
  app.post("/api/progress/weekly", requireAuth, async (req, res) => {
    try {
      const validated = insertWeeklyProgressSchema.parse(req.body);
      const progress = await storage.createWeeklyProgress(validated);
      res.status(201).json(progress);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: fromZodError(error).message });
      }
      console.error("Error creating weekly progress:", error);
      res.status(500).json({ error: "Failed to create weekly progress" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
