// Referenced from javascript_auth_all_persistance blueprint
import { drizzle } from "drizzle-orm/neon-serverless";
import { Pool, neonConfig } from "@neondatabase/serverless";
import { eq, desc, and, sql } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import ws from "ws";
import * as schema from "@shared/schema";
import type {
  User,
  InsertUser,
  Student,
  InsertStudent,
  SurveyQuestion,
  InsertSurveyQuestion,
  SurveyResponse,
  InsertSurveyResponse,
  WeeklyProgress,
  InsertWeeklyProgress,
  StudentWithUser,
} from "@shared/schema";

// Configure Neon for serverless with WebSocket
neonConfig.webSocketConstructor = ws;

const pool = new Pool({ connectionString: process.env.DATABASE_URL! });
const db = drizzle(pool, { schema });

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // Session store
  sessionStore: session.Store;

  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Student methods
  getStudentByUserId(userId: string): Promise<Student | undefined>;
  getStudentById(id: string): Promise<Student | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: string, student: Partial<Student>): Promise<Student | undefined>;
  getAllStudentsWithUsers(): Promise<StudentWithUser[]>;

  // Survey questions methods
  getAllSurveyQuestions(): Promise<SurveyQuestion[]>;
  createSurveyQuestion(question: InsertSurveyQuestion): Promise<SurveyQuestion>;
  seedSurveyQuestions(): Promise<void>;

  // Survey responses methods
  createSurveyResponse(response: InsertSurveyResponse): Promise<SurveyResponse>;
  createMultipleSurveyResponses(responses: InsertSurveyResponse[]): Promise<void>;
  getStudentResponses(studentId: string): Promise<SurveyResponse[]>;

  // Weekly progress methods
  getStudentWeeklyProgress(studentId: string): Promise<WeeklyProgress[]>;
  createWeeklyProgress(progress: InsertWeeklyProgress): Promise<WeeklyProgress>;

  // Stats methods
  getTeacherStats(): Promise<{
    totalStudents: number;
    averageGrade: number;
    completionRate: number;
    surveysCompleted: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    const users = await db.select().from(schema.users).where(eq(schema.users.id, id));
    return users[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const users = await db.select().from(schema.users).where(eq(schema.users.username, username));
    return users[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const users = await db.select().from(schema.users).where(eq(schema.users.email, email));
    return users[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const users = await db.insert(schema.users).values(insertUser).returning();
    return users[0];
  }

  // Student methods
  async getStudentByUserId(userId: string): Promise<Student | undefined> {
    const students = await db
      .select()
      .from(schema.students)
      .where(eq(schema.students.userId, userId));
    return students[0];
  }

  async getStudentById(id: string): Promise<Student | undefined> {
    const students = await db.select().from(schema.students).where(eq(schema.students.id, id));
    return students[0];
  }

  async createStudent(insertStudent: InsertStudent): Promise<Student> {
    const students = await db.insert(schema.students).values(insertStudent).returning();
    return students[0];
  }

  async updateStudent(id: string, updateData: Partial<Student>): Promise<Student | undefined> {
    const students = await db
      .update(schema.students)
      .set(updateData)
      .where(eq(schema.students.id, id))
      .returning();
    return students[0];
  }

  async getAllStudentsWithUsers(): Promise<StudentWithUser[]> {
    const results = await db
      .select()
      .from(schema.students)
      .leftJoin(schema.users, eq(schema.students.userId, schema.users.id))
      .orderBy(desc(schema.students.createdAt));

    return results
      .filter((row) => row.users !== null)
      .map((row) => ({
        ...row.students,
        user: row.users!,
      }));
  }

  // Survey questions methods
  async getAllSurveyQuestions(): Promise<SurveyQuestion[]> {
    return await db.select().from(schema.surveyQuestions).orderBy(schema.surveyQuestions.order);
  }

  async createSurveyQuestion(insertQuestion: InsertSurveyQuestion): Promise<SurveyQuestion> {
    const questions = await db.insert(schema.surveyQuestions).values(insertQuestion).returning();
    return questions[0];
  }

  async seedSurveyQuestions(): Promise<void> {
    const existingQuestions = await this.getAllSurveyQuestions();
    if (existingQuestions.length > 0) {
      return; // Already seeded
    }

    const questions: InsertSurveyQuestion[] = [
      // Personal Info
      {
        questionText: "¿Cuál es tu carrera?",
        questionType: "text",
        category: "personal_info",
        order: 1,
      },
      {
        questionText: "¿En qué semestre te encuentras?",
        questionType: "text",
        category: "personal_info",
        order: 2,
      },
      {
        questionText: "¿Cuál es tu matrícula?",
        questionType: "text",
        category: "personal_info",
        order: 3,
      },

      // Cognitive Profile - Sequential vs Global
      {
        questionText: "Prefiero aprender paso a paso de manera ordenada",
        questionType: "cognitive_scale",
        category: "cognitive_profile",
        cognitiveProfileDimension: "sequential_global",
        order: 4,
      },
      {
        questionText: "Me gusta tener una visión general antes de entrar en detalles",
        questionType: "cognitive_scale",
        category: "cognitive_profile",
        cognitiveProfileDimension: "sequential_global",
        order: 5,
      },

      // Cognitive Profile - Active vs Reflective
      {
        questionText: "Aprendo mejor cuando puedo hacer algo activamente",
        questionType: "cognitive_scale",
        category: "cognitive_profile",
        cognitiveProfileDimension: "active_reflective",
        order: 6,
      },
      {
        questionText: "Prefiero pensar primero antes de actuar",
        questionType: "cognitive_scale",
        category: "cognitive_profile",
        cognitiveProfileDimension: "active_reflective",
        order: 7,
      },

      // Cognitive Profile - Sensorial vs Intuitive
      {
        questionText: "Prefiero trabajar con hechos y datos concretos",
        questionType: "cognitive_scale",
        category: "cognitive_profile",
        cognitiveProfileDimension: "sensorial_intuitive",
        order: 8,
      },
      {
        questionText: "Me gustan los conceptos abstractos y las teorías",
        questionType: "cognitive_scale",
        category: "cognitive_profile",
        cognitiveProfileDimension: "sensorial_intuitive",
        order: 9,
      },

      // Learning Preferences
      {
        questionText: "¿Qué método de estudio prefieres?",
        questionType: "multiple_choice",
        category: "learning_preferences",
        options: ["Individual", "En grupo", "Combinado"],
        order: 10,
      },
      {
        questionText: "¿Cuántas horas dedicas al estudio por semana?",
        questionType: "likert",
        category: "learning_preferences",
        order: 11,
      },
    ];

    for (const question of questions) {
      await this.createSurveyQuestion(question);
    }
  }

  // Survey responses methods
  async createSurveyResponse(insertResponse: InsertSurveyResponse): Promise<SurveyResponse> {
    const responses = await db.insert(schema.surveyResponses).values(insertResponse).returning();
    return responses[0];
  }

  async createMultipleSurveyResponses(insertResponses: InsertSurveyResponse[]): Promise<void> {
    if (insertResponses.length === 0) return;

    await db.insert(schema.surveyResponses).values(insertResponses);

    // Calculate cognitive profile from responses
    const studentId = insertResponses[0].studentId;
    const responses = await this.getStudentResponses(studentId);
    const questions = await this.getAllSurveyQuestions();

    let sequentialGlobal = 0;
    let activeReflective = 0;
    let sensorialIntuitive = 0;

    for (const response of responses) {
      const question = questions.find((q) => q.id === response.questionId);
      if (!question || !question.cognitiveProfileDimension || response.responseValue === null) {
        continue;
      }

      const value = response.responseValue;
      if (question.cognitiveProfileDimension === "sequential_global") {
        sequentialGlobal += value;
      } else if (question.cognitiveProfileDimension === "active_reflective") {
        activeReflective += value;
      } else if (question.cognitiveProfileDimension === "sensorial_intuitive") {
        sensorialIntuitive += value;
      }
    }

    // Update student cognitive profile
    await this.updateStudent(studentId, {
      profileSequentialGlobal: sequentialGlobal,
      profileActiveReflective: activeReflective,
      profileSensorialIntuitive: sensorialIntuitive,
      surveyCompleted: true,
    });

    // Extract student info from responses
    const studentInfoResponses = responses.filter((r) => {
      const q = questions.find((q) => q.id === r.questionId);
      return q?.category === "personal_info";
    });

    // Update student data from responses
    const careerQuestion = questions.find((q) => q.questionText.includes("carrera"));
    const semesterQuestion = questions.find((q) => q.questionText.includes("semestre"));
    const matriculaQuestion = questions.find((q) => q.questionText.includes("matrícula"));

    const careerResponse = studentInfoResponses.find((r) => r.questionId === careerQuestion?.id);
    const semesterResponse = studentInfoResponses.find(
      (r) => r.questionId === semesterQuestion?.id
    );
    const matriculaResponse = studentInfoResponses.find(
      (r) => r.questionId === matriculaQuestion?.id
    );

    const updateData: Partial<Student> = {};
    if (careerResponse?.responseText) {
      updateData.career = careerResponse.responseText;
    }
    if (semesterResponse?.responseText) {
      const semester = parseInt(semesterResponse.responseText);
      if (!isNaN(semester)) {
        updateData.semester = semester;
      }
    }
    if (matriculaResponse?.responseText) {
      updateData.studentId = matriculaResponse.responseText;
    }

    if (Object.keys(updateData).length > 0) {
      await this.updateStudent(studentId, updateData);
    }
  }

  async getStudentResponses(studentId: string): Promise<SurveyResponse[]> {
    return await db
      .select()
      .from(schema.surveyResponses)
      .where(eq(schema.surveyResponses.studentId, studentId));
  }

  // Weekly progress methods
  async getStudentWeeklyProgress(studentId: string): Promise<WeeklyProgress[]> {
    return await db
      .select()
      .from(schema.weeklyProgress)
      .where(eq(schema.weeklyProgress.studentId, studentId))
      .orderBy(schema.weeklyProgress.week);
  }

  async createWeeklyProgress(insertProgress: InsertWeeklyProgress): Promise<WeeklyProgress> {
    const progress = await db.insert(schema.weeklyProgress).values(insertProgress).returning();
    return progress[0];
  }

  // Stats methods
  async getTeacherStats(): Promise<{
    totalStudents: number;
    averageGrade: number;
    completionRate: number;
    surveysCompleted: number;
  }> {
    const students = await db.select().from(schema.students);

    const totalStudents = students.length;
    const surveysCompleted = students.filter((s) => s.surveyCompleted).length;

    const averageGrade =
      students.reduce((acc, s) => acc + (Number(s.average) || 0), 0) / (totalStudents || 1);

    const completionRate =
      students.reduce((acc, s) => acc + (Number(s.completionRate) || 0), 0) / (totalStudents || 1);

    return {
      totalStudents,
      averageGrade,
      completionRate,
      surveysCompleted,
    };
  }
}

export const storage = new DatabaseStorage();
