# ITSU Analytics Design Guidelines

## Design Approach: Material Design for Educational Analytics

**Primary Focus:** Information-dense educational analytics platform prioritizing data clarity, usability, and professional presentation over decorative elements.

**Design System:** Material Design principles adapted for educational data visualization and student progress tracking.

---

## Color System

### Light Mode
- **Background:** 0 0% 100%
- **Foreground:** 240 10% 3.9%
- **Primary:** 210 90% 48% (Educational Blue)
- **Secondary:** 210 20% 92%
- **Muted:** 210 15% 95%
- **Border:** 214 15% 91%

### Dark Mode
- **Background:** 240 10% 3.9%
- **Foreground:** 0 0% 98%
- **Primary:** 210 85% 55%
- **Card:** 240 8% 8%
- **Border:** 214 15% 15%

### Data Visualization Colors
- **Chart 1 (Blue):** 210 85% 50%
- **Chart 2 (Teal):** 185 70% 48%
- **Chart 3 (Purple):** 265 75% 55%
- **Chart 4 (Green):** 145 60% 48%
- **Chart 5 (Amber):** 35 85% 58%

### Semantic Colors
- **Success/High Performance:** 145 65% 45%
- **Warning/Medium:** 35 90% 55%
- **Error/Low Performance:** 0 75% 52%
- **Pre-DSS Baseline:** 215 15% 45%
- **Post-DSS Improvement:** 145 65% 45%

---

## Typography

**Font Families:**
- **Sans:** Inter (primary UI text)
- **Serif:** Merriweather (data labels, headers)
- **Mono:** JetBrains Mono (student IDs, codes)

**Scale:**
- Display: text-4xl font-bold (analytics titles)
- Headings: text-2xl to text-xl font-semibold
- Body: text-base (16px)
- Labels: text-sm font-medium
- Captions: text-xs text-muted-foreground

---

## Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 8, 12, 16 (e.g., p-4, m-8, gap-12)

**Container Widths:**
- Full-width dashboards: max-w-7xl mx-auto
- Content sections: max-w-6xl
- Forms: max-w-2xl

**Grid Patterns:**
- Metrics cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6
- Charts: grid-cols-1 lg:grid-cols-2 gap-8
- Student lists: Full-width responsive table

---

## Component Library

### Analytics Dashboard

**Metric Overview Cards:**
- Grid layout with hover:shadow-md transition
- Large number display (text-4xl font-bold)
- Metric label (text-sm text-muted-foreground)
- Trend indicator (arrow + percentage)
- Mini sparkline chart (24px height)

**Progress Comparison Chart:**
- Recharts Line Chart with dual Y-axis
- Pre-DSS (dashed, muted) vs Post-DSS (solid, primary)
- Interactive tooltips with exact values
- Grid lines at opacity-10
- Aspect ratio [16/9] responsive

**Student Clustering Cards:**
- Grid 2-3 columns with cluster color border-l-4
- Cluster badge (top-left with group color)
- Student count (center, large)
- Common characteristics list
- Dominant profile badges
- "View Students" outline button

### Filtering System

**Filter Bar:**
- Sticky position (top-16) below header
- Horizontal gap-4 layout with search, semester, career dropdowns
- Multi-select cognitive profile filter
- Clear filters button (ghost variant)
- Active filters as dismissible badges
- Mobile: Collapsible drawer

### Progress Tracking

**Weekly Progress Grid:**
- Timeline of 16 weeks with snap-scroll
- Each cell: week badge, tasks completed/total, average score
- Current week highlighted (ring-2 ring-primary)
- Past weeks normal, future opacity-50

**Task Completion Tracker:**
- Circular progress (Radix Progress)
- Ring color based on percentage (0-40% destructive, 41-70% amber, 71-100% green)
- Percentage in center (text-2xl)
- Pending tasks list (max 3)

---

## Chart Styling Standards

**All Recharts Components:**
- Font: Inter
- Axis labels: text-xs text-muted-foreground
- Grid: stroke-border opacity-50
- Tooltips: popover background, shadow-lg, rounded-md
- Animations: 500ms fade-in initial, 300ms data updates
- Mobile: Hide crowded axis labels, reduce height

---

## Accessibility

- All charts include text fallback descriptions
- Color + patterns/labels for data indicators
- Keyboard navigation for interactive elements
- ARIA labels on export/filter buttons
- Consistent dark mode across all inputs/fields

---

## Images & Illustrations

**Empty States Only:**
- No data yet: Line art graphs/charts illustration
- No students: Group silhouettes
- Export success: Checkmark with document
- All images: max-w-xs mx-auto, grayscale with primary accent

**No Hero Images** - Utility application focused on data/functionality

---

## Interactions

- Hover: shadow-md transition on cards
- Active filters: ring-2 ring-primary
- Loading: Skeleton loaders for data tables
- Success: Toast notifications (top-right)
- Errors: Inline validation + error toast
- Minimal animations - only functional transitions